<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Google\Cloud\Dialogflow\V2\SessionsClient;
use Google\Cloud\Dialogflow\V2\QueryInput;
use Google\Cloud\Dialogflow\V2\TextInput;

class DialogflowController extends Controller
{
    public function handle(Request $request)
    {
        // Get the text query from the Dialogflow request
        $query = $request->input('text');

        // Create a SessionsClient using Google Cloud credentials
        $sessionsClient = new SessionsClient();
        $session = $sessionsClient->sessionName('healthcarebot-pgfv', uniqid());

        // Create a QueryInput using the text query
        $textInput = (new QueryInput())
            ->setText((new TextInput())->setText($query)->setLanguageCode('en-US'));

        // Perform a detectIntent call to Dialogflow
        $response = $sessionsClient->detectIntent($session, $textInput);
dd($response);
        // Extract and handle the response from Dialogflow (e.g., send a response back to the user)

        // Close the SessionsClient
        $sessionsClient->close();
    }
}
